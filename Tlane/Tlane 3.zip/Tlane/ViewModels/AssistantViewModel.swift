import Foundation
import SwiftData

struct ChatMessage: Identifiable, Equatable {
  let id = UUID()
  let role: Role
  let content: String
  let timestamp: Date

  enum Role: String {
    case user
    case assistant
    case system  // para mensajes informativos ("sin Apple Intelligence...")
  }
}

@Observable
@MainActor
final class AssistantViewModel {
  var messages: [ChatMessage] = []
  var input: String = ""
  var isTyping: Bool = false
  var isAvailable: Bool = true
  var availabilityReason: String?

  private let session = AssistantSession()

  /// Se inyecta cada vez que el usuario envía un mensaje — contiene
  /// el snapshot actual de productos + ventas en formato textual.
  var contextProvider: () -> String = { "" }

  // MARK: - Mensaje de bienvenida

  /// Llama esto la primera vez que se abre el chat. Si Apple Intelligence
  /// no está disponible, muestra mensaje explicativo.
  func bootstrapIfNeeded() async {
    guard messages.isEmpty else { return }

    let status = await session.checkAvailability()
    isAvailable = status.isAvailable
    availabilityReason = status.reason

    if status.isAvailable {
      messages.append(ChatMessage(
        role: .assistant,
        content: "¡Hola! Soy tu copiloto de Tlane. Puedo ayudarte a analizar tus ventas, sugerir qué impulsar, o detectar productos que no se están moviendo. ¿Qué quieres saber?",
        timestamp: .now
      ))
    } else {
      messages.append(ChatMessage(
        role: .system,
        content: "Tu copiloto está descansando. \(status.reason ?? "")\n\nMientras, aquí tienes un consejo general: los días soleados suelen aumentar el flujo en el mercado. Acomoda tus piezas más coloridas al frente.",
        timestamp: .now
      ))
    }
  }

  // MARK: - Enviar mensaje

  func sendCurrentInput() async {
    let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty, !isTyping, isAvailable else { return }

    // Append user message
    let userMsg = ChatMessage(role: .user, content: trimmed, timestamp: .now)
    messages.append(userMsg)
    input = ""
    isTyping = true

    let businessContext = contextProvider()

    do {
      let response = try await session.chat(
        userMessage: trimmed,
        businessContext: businessContext
      )
      messages.append(ChatMessage(
        role: .assistant,
        content: response,
        timestamp: .now
      ))
    } catch AssistantError.refusal {
      messages.append(ChatMessage(
        role: .system,
        content: "No pude responder eso. Intenta reformular la pregunta.",
        timestamp: .now
      ))
    } catch AssistantError.notAvailable(let reason) {
      isAvailable = false
      availabilityReason = reason
      messages.append(ChatMessage(
        role: .system,
        content: "Tu copiloto se desconectó: \(reason)",
        timestamp: .now
      ))
    } catch {
      messages.append(ChatMessage(
        role: .system,
        content: "Hubo un problema. Intenta de nuevo.",
        timestamp: .now
      ))
    }

    isTyping = false
  }

  // MARK: - Sugerencias rápidas

  /// Preguntas de ejemplo para que el usuario no empiece desde cero.
  /// Se muestran como chips arriba del input en el chat vacío.
  let suggestedPrompts: [String] = [
    "¿Qué debería impulsar esta semana?",
    "¿Qué productos no se están vendiendo?",
    "¿Cuánto he vendido hoy?",
    "Dame un resumen del negocio"
  ]

  func sendSuggestion(_ text: String) async {
    input = text
    await sendCurrentInput()
  }

  // MARK: - Reset

  func resetConversation() async {
    await session.resetConversation()
    messages = []
    await bootstrapIfNeeded()
  }
}
