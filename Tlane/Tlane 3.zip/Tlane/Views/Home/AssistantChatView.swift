import SwiftUI

struct AssistantChatView: View {
  @Bindable var viewModel: AssistantViewModel
  @FocusState private var inputFocused: Bool

  var body: some View {
    VStack(spacing: 0) {
      messagesScrollView
      Divider()
      inputBar
    }
    .task {
      await viewModel.bootstrapIfNeeded()
    }
  }

  // MARK: - Scroll de mensajes

  private var messagesScrollView: some View {
    ScrollViewReader { proxy in
      ScrollView {
        VStack(alignment: .leading, spacing: 10) {
          ForEach(viewModel.messages) { message in
            messageBubble(message)
              .id(message.id)
          }

          if viewModel.isTyping {
            typingIndicator
              .id("typing")
          }

          // Sugerencias cuando solo existe el mensaje de bienvenida
          if viewModel.messages.count == 1 && !viewModel.isTyping && viewModel.isAvailable {
            suggestionsChips
              .padding(.top, 8)
          }
        }
        .padding(12)
      }
      .onChange(of: viewModel.messages.count) { _, _ in
        withAnimation(.easeOut(duration: 0.2)) {
          if let last = viewModel.messages.last {
            proxy.scrollTo(last.id, anchor: .bottom)
          }
        }
      }
      .onChange(of: viewModel.isTyping) { _, newValue in
        if newValue {
          withAnimation(.easeOut(duration: 0.2)) {
            proxy.scrollTo("typing", anchor: .bottom)
          }
        }
      }
    }
  }

  // MARK: - Burbuja individual

  @ViewBuilder
  private func messageBubble(_ message: ChatMessage) -> some View {
    switch message.role {
    case .user:
      HStack {
        Spacer(minLength: 40)
        Text(message.content)
          .font(.subheadline)
          .foregroundStyle(.white)
          .padding(.horizontal, 14)
          .padding(.vertical, 10)
          .background(Color.tlaneGreen, in: RoundedRectangle(cornerRadius: 16))
      }

    case .assistant:
      HStack(alignment: .top, spacing: 8) {
        Image(systemName: "sparkles")
          .font(.caption)
          .foregroundStyle(Color.tlaneGreen)
          .padding(.top, 4)
        Text(message.content)
          .font(.subheadline)
          .foregroundStyle(.primary)
          .padding(.horizontal, 14)
          .padding(.vertical, 10)
          .background(
            Color(.secondarySystemGroupedBackground),
            in: RoundedRectangle(cornerRadius: 16)
          )
        Spacer(minLength: 40)
      }

    case .system:
      HStack {
        Image(systemName: "info.circle")
          .foregroundStyle(.secondary)
          .font(.caption)
        Text(message.content)
          .font(.caption)
          .foregroundStyle(.secondary)
          .multilineTextAlignment(.leading)
        Spacer(minLength: 0)
      }
      .padding(.horizontal, 12)
      .padding(.vertical, 10)
      .background(
        Color(.tertiarySystemGroupedBackground),
        in: RoundedRectangle(cornerRadius: 12)
      )
    }
  }

  // MARK: - Indicador "está escribiendo"

  private var typingIndicator: some View {
    HStack(alignment: .top, spacing: 8) {
      Image(systemName: "sparkles")
        .font(.caption)
        .foregroundStyle(Color.tlaneGreen)
        .padding(.top, 4)

      HStack(spacing: 4) {
        ForEach(0..<3) { i in
          Circle()
            .fill(Color.secondary)
            .frame(width: 6, height: 6)
            .opacity(0.6)
            .phaseAnimator([0, 1, 2]) { view, phase in
              view.opacity(phase == i % 3 ? 1.0 : 0.4)
            } animation: { _ in
              .easeInOut(duration: 0.4)
            }
        }
      }
      .padding(.horizontal, 14)
      .padding(.vertical, 12)
      .background(
        Color(.secondarySystemGroupedBackground),
        in: RoundedRectangle(cornerRadius: 16)
      )
      Spacer()
    }
  }

  // MARK: - Chips de sugerencias

  private var suggestionsChips: some View {
    VStack(alignment: .leading, spacing: 8) {
      Text("Prueba preguntar:")
        .font(.caption)
        .foregroundStyle(.secondary)
        .padding(.horizontal, 4)

      VStack(alignment: .leading, spacing: 6) {
        ForEach(viewModel.suggestedPrompts, id: \.self) { suggestion in
          Button {
            Task { await viewModel.sendSuggestion(suggestion) }
          } label: {
            HStack {
              Text(suggestion)
                .font(.caption)
                .foregroundStyle(Color.tlaneGreen)
                .multilineTextAlignment(.leading)
              Spacer()
              Image(systemName: "arrow.up.forward.circle.fill")
                .font(.caption)
                .foregroundStyle(Color.tlaneGreen.opacity(0.7))
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(
              Color.tlaneGreen.opacity(0.08),
              in: RoundedRectangle(cornerRadius: 10)
            )
          }
        }
      }
    }
  }

  // MARK: - Input bar

  private var inputBar: some View {
    HStack(spacing: 8) {
      TextField(
        viewModel.isAvailable ? "Pregunta algo..." : "Copiloto no disponible",
        text: $viewModel.input,
        axis: .vertical
      )
      .font(.subheadline)
      .textFieldStyle(.plain)
      .lineLimit(1...4)
      .padding(.horizontal, 12)
      .padding(.vertical, 10)
      .background(
        Color(.secondarySystemGroupedBackground),
        in: RoundedRectangle(cornerRadius: 18)
      )
      .focused($inputFocused)
      .disabled(!viewModel.isAvailable || viewModel.isTyping)
      .onSubmit {
        Task { await viewModel.sendCurrentInput() }
      }

      Button {
        Task { await viewModel.sendCurrentInput() }
      } label: {
        Image(systemName: "arrow.up.circle.fill")
          .font(.title)
          .foregroundStyle(
            canSend ? Color.tlaneGreen : Color(.systemGray4)
          )
      }
      .disabled(!canSend)
    }
    .padding(12)
    .background(.regularMaterial)
  }

  private var canSend: Bool {
    !viewModel.input.trimmingCharacters(in: .whitespaces).isEmpty
      && !viewModel.isTyping
      && viewModel.isAvailable
  }
}
