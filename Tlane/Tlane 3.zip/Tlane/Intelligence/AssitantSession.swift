import FoundationModels
import Foundation

enum AssistantError: Error {
  case notAvailable(reason: String)
  case refusal
  case generationFailed(Error)
}

/// Sesión conversacional con Apple Intelligence, contextualizada con
/// los datos del negocio (inventario + ventas). Reemplaza a ConsejeroSession
/// pero mantiene el método generateInsight() para retrocompatibilidad con
/// ConsejeroCardView.
actor AssistantSession {
  private var chatSession: LanguageModelSession?
  private var lastBusinessContext: String = ""

  // MARK: - Availability

  struct AvailabilityStatus {
    let isAvailable: Bool
    let reason: String?
  }

  func checkAvailability() -> AvailabilityStatus {
    let model = SystemLanguageModel.default
    switch model.availability {
    case .available:
      return AvailabilityStatus(isAvailable: true, reason: nil)
    case .unavailable(let unavailableReason):
      let message: String
      switch unavailableReason {
      case .appleIntelligenceNotEnabled:
        message = "Apple Intelligence no está activado en este dispositivo."
      case .deviceNotEligible:
        message = "Este dispositivo no soporta Apple Intelligence."
      case .modelNotReady:
        message = "El modelo aún se está descargando. Intenta en unos minutos."
      @unknown default:
        message = "Apple Intelligence no está disponible."
      }
      return AvailabilityStatus(isAvailable: false, reason: message)
    }
  }

  // MARK: - System instructions

  /// Instrucciones que definen el comportamiento del asistente.
  /// Se inyectan una sola vez al crear la sesión.
  private func buildInstructions(businessContext: String) -> String {
    """
    Eres el copiloto de negocio de Tlane, una app para artesanos y comerciantes \
    de tianguis en México. Hablas en español mexicano coloquial pero respetuoso, \
    como un socio experimentado que conoce al dedillo el inventario y las ventas \
    del usuario.

    REGLAS ESTRICTAS:
    - Usa SIEMPRE los datos reales del CONTEXTO DEL NEGOCIO que se te proporciona. \
    Nunca inventes productos, cantidades, ni ventas.
    - Si el usuario pregunta algo que no puedes responder con los datos, dilo \
    honestamente: "No tengo ese dato".
    - Da consejos CONCRETOS y ACCIONABLES. Nada de frases genéricas tipo \
    "esfuérzate más". Mejor: "el llavero no se ha vendido esta semana, considera \
    bajarlo a $65 o ponerlo al frente del puesto".
    - Mantén respuestas BREVES: máximo 3-4 oraciones a menos que el usuario \
    pida detalle.
    - Cuando des recomendaciones, sé específico con nombres de productos reales \
    del inventario.
    - Si el usuario te pide ejecutar acciones ("quita X", "agrega Y"), explícale \
    amablemente que por ahora solo puedes aconsejar, y que las acciones las \
    hace él desde la app.

    CONTEXTO DEL NEGOCIO (datos en vivo):
    \(businessContext)
    """
  }

  // MARK: - Chat multi-turno

  /// Envía un mensaje al asistente y recibe respuesta.
  /// Mantiene el historial entre llamadas durante la misma sesión.
  /// Si el contexto del negocio cambió significativamente, recrea la sesión.
  func chat(userMessage: String, businessContext: String) async throws -> String {
    let status = checkAvailability()
    guard status.isAvailable else {
      throw AssistantError.notAvailable(reason: status.reason ?? "No disponible")
    }

    // Si el contexto cambió (ej: se registró una venta nueva), recreamos
    // la sesión para que el asistente tenga datos frescos.
    if chatSession == nil || businessContext != lastBusinessContext {
      chatSession = LanguageModelSession(
        instructions: buildInstructions(businessContext: businessContext)
      )
      lastBusinessContext = businessContext
    }

    guard let session = chatSession else {
      throw AssistantError.notAvailable(reason: "No se pudo crear la sesión")
    }

    do {
      let response = try await session.respond(to: userMessage)
      return response.content
    } catch let error as LanguageModelSession.GenerationError {
      if case .refusal = error {
        throw AssistantError.refusal
      }
      throw AssistantError.generationFailed(error)
    } catch {
      throw AssistantError.generationFailed(error)
    }
  }

  /// Fuerza crear una nueva sesión (limpia historial).
  func resetConversation() {
    chatSession = nil
    lastBusinessContext = ""
  }

  // MARK: - Retrocompatibilidad con ConsejeroCardView

  /// Genera un SalesInsight estructurado. Usado por el flujo original
  /// del Consejero (no por el chat).
  func generateInsight(businessContext: String) async throws -> SalesInsight {
    let status = checkAvailability()
    guard status.isAvailable else {
      throw AssistantError.notAvailable(reason: status.reason ?? "No disponible")
    }

    let instructions = """
    Eres un consejero financiero cercano para comerciantes mexicanos. \
    Hablas en español mexicano coloquial. Das consejos prácticos y específicos \
    basados en los datos reales que se te proporcionan. Nunca inventes productos \
    ni cifras.
    """

    let prompt = """
    \(businessContext)

    Basándote en estos datos reales del negocio, genera un consejo breve y \
    concreto para el comerciante.
    """

    let session = LanguageModelSession(instructions: instructions)
    do {
      let response = try await session.respond(
        to: prompt,
        generating: SalesInsight.self
      )
      return response.content
    } catch let error as LanguageModelSession.GenerationError {
      if case .refusal = error {
        throw AssistantError.refusal
      }
      throw AssistantError.generationFailed(error)
    } catch {
      throw AssistantError.generationFailed(error)
    }
  }
}
